# Assignment 1.06 | Fog of War
- This assignment is for CS 327 Spring 2021
- We used Prof. Sheaffer's 1.05 assignment code for this assignment 
- Rules
  - Press 'f' to look at the no fog map, disappears once you make a move
  - Press 'g' to start teleport method, from there, you can press 'r' to teleport somewhere random or 'g' again to get out of teleport
    - Cannot go into immutable wall bounds
    - If teleported and surrounded by rock, user won't move
    - Will see a fog free dungeon while in teleport mode

## Project Team Members:
- MyTien Kien *(kmytien)*
- Haylee Lawrence *(hayleel)*
- Sanjana Amatya *(samatya)*


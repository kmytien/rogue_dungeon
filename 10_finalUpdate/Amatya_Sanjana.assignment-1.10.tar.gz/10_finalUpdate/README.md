# Assignment 1.10 | Choose Your Own Assignment
- This assignment is for CS 327 Spring 2021
- We used Prof. Schaeffer's solution code for 1.09
- New features ** FOR THE NEW FEATURES TO WORK PROPERLY, USE THE UPDATED OBJECT_DESC.TXT PROVIDED
  - Health potions randomly generate on the floor and can heal 25%-100% of a players health (H)
     - Potions generate as the symbol ^
     - Potions are automatically taken and drunk when walked over UNLESS the player is at full health
  - Use the --hpset command to input a custom hp level for the PC (H)
  - PC will be equipped with ONLY 3 grenades that will only target monsters and items in a 3x3 radius (M)
     - Can use bombs with the symbol *
     - PC can be able to throw it wherever terrain has been spotted
     - Will be able to kill monsters regardless on how high their HP is
     - Will destroy any objects in area of explosion
  - The PC is now able to throw random equipment they have at monsters in a desperate attempt to stay alive (S)
     - Press W to throw a random inventory item at any chosen monster in view (if the PC has picked up an item)
     - Breaking the laws of physics, the PC is able to throw their unused items for as much damage as the PC is able to do (damage dice amnt)
       - (this means that if the PC is OP, they will be able to obliterate a nearby monster with a prom dress)


## Project Team Members:
- MyTien Kien *(kmytien)*
- Haylee Lawrence *(hayleel)*
- Sanjana Amatya *(samatya)*

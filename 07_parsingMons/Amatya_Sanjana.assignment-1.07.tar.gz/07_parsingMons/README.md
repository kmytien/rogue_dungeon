# Assignment 1.07 | Parsing Monsters
- This assignment is for CS 327 Spring 2021
- We used Prof. Schaeffer's solution code for 1.06
- All of our new code is in rlg327.cpp before the main function
- We only parsed monsters

## Project Team Members:
- MyTien Kien *(kmytien)*
- Haylee Lawrence *(hayleel)*
- Sanjana Amatya *(samatya)*


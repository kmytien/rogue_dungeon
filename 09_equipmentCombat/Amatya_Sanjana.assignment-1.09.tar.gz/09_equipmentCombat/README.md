# Assignment 1.09 | PC Equipment and Combat
- This assignment is for CS 327 Spring 2021
- We used Prof. Schaeffer's solution code for 1.08
- Defaults
  - PC's default hp is 3000
  - When you walk over an item it automatically picks up
  - Picked up items go to the inventory where you have to press w to wear them (doesn't automatically equip)
- Bugs
  - Occasionally a monster will stand on the character

## Project Team Members:
- MyTien Kien *(kmytien)*
- Haylee Lawrence *(hayleel)*
- Sanjana Amatya *(samatya)*



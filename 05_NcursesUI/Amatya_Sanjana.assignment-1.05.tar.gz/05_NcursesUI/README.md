# Assignment 1.05 | User Interface with NCurses
- This assignment is for CS 327 Spring 2021
- We used Prof. Sheaffer's 1.04 assignment code for this assignment 
- We did not implement any new keys (just the keys from the list on the first page of assignment pdf)

## Project Team Members:
- MyTien Kien *(kmytien)*
- Haylee Lawrence *(hayleel)*
- Sanjana Amatya *(samatya)*


# Assignment 1.02 | Dungeon Saving and Loading
- This assignment is for CS 327 Spring 2021
- We used our 1.01 assignment code instead of Prof. Sheaffer's

- This project was designed to take the parameters --save and/or --load, or no parameters
- When save is called, it saves the dungeon layout to the disk
- When load is called, it loads a dungeon layout from the disk and prints to console
- When save and load are called, a dungeon is loaded from the disk, printed, and then saved back to the disk
- When there are no parameters, program generates a dungeon and prints to console

## Project Team Members:
- MyTien Kien *(kmytien)*
- Haylee Lawrence *(hayleel)*
- Sanjana Amatya *(samatya)*

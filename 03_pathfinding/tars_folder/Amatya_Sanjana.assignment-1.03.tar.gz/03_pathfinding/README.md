# Assignment 1.03 | Path Finding
- This assignment is for CS 327 Spring 2021
- We used Prof. Sheaffer's 1.02 assignment code for this assignment 
- This project was designed to implement a paths using the Dijkstra’s Algorithm
- Some monsters will be able to tunnel through walls 
- The rest can move through open space 

## Project Team Members:
- MyTien Kien *(kmytien)*
- Haylee Lawrence *(hayleel)*
- Sanjana Amatya *(samatya)*
